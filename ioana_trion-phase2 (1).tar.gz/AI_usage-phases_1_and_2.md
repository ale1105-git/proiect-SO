# AI_usage - Documentarea utilizării AI în cadrul proiectului (Faza 1 și 2)

## Instrument folosit
Claude (claude-sonnet-4-20250514) / Gemini - conversație interactivă pentru scriere, validare și optimizare de cod.

## FAZA 1: Manipularea Fișierelor și Permisiuni

## Functia 1: `parse_condition`

### Prompt dat AI-ului - in limba engleza 
> "I have a C string of the form `field:op:value` where op can be `==`, `!=`, `<`, `<=`, `>`, `>=`.
> Write a function `int parse_condition(const char *input, char *field, char *op, char *value)`
> that splits it into the three parts and returns 0 on success, -1 on error."

### Ce a generat AI-ul ?
AI-ul a generat o varianta care folosea `strtok(input, ":")` pentru a imparti sirul in tokeni.

### Ce am schimbat si de ce ?
Varianta cu `strtok` era gresita, deoarece `strtok` ar fi spart sirul dupa **orice** `:`, inclusiv
in interiorul unui operator compus (`<=`, `>=`). De exemplu, pentru `severity:>=:2` ar fi
produs field=`severity`, op=`>`, value=`=:2`, ceea ce ar fi fost incorect.

Am rescris functia folosind `strchr` - care ne ajuta sa cautam un singur caracter, pentru a cauta manual primul si al doilea `:`, calculand lungimile substring-urilor cu pointer aritmetic. Aceasta abordare pastreaza corect operatorul de doua caractere, spre deosebire de strtok.

De asemenea AI-ul nu verifica dimensiunile bufferelor de iesire, iar acest lucru poate duce la buffer overflow.
Am adaugat verificarile `flen >= 32` si `olen >= 4`.

### Ce am invatat implementand aceasta functie cu ajutorul AI?
`strtok` nu e potrivit cand delimitatorul apare si in interiorul unui token valid.
Aritmetica de pointeri cu `strchr` ofera control precis

## Functia 2: `match_condition`

### Prompt dat AI-ului
> "Given this C struct:
> ```c
> typedef struct {
>     int    id;
>     char   inspector[64];
>     float  latitude;
>     float  longitude;
>     char   category[32];
>     int    severity;
>     time_t timestamp;
>     char   description[128];
> } Report;
> ```
> Write `int match_condition(Report *r, const char *field, const char *op, const char *value)`
> that returns 1 if the record satisfies `field op value`, 0 otherwise.
> Support fields: severity, category, inspector, timestamp.
> Operators: ==, !=, <, <=, >, >=."

### Ce a generat AI-ul ?

AI-ul a generat o functie cu structura corecta (if/else pe field, if/else pe operator),
dar cu doua probleme:

1. Pentru campul `timestamp` folosea `atoi(value)` care returneaza `int` – incorect,
   deoarece `time_t` pe sisteme moderne e `long` (64 biti). Valori mari de timestamp
   erau trunchiate si astfel apareau probleme.

2. Nu exista un `else` final pentru camp necunoscut – functia returna 0 in tacere,
   fara niciun mesaj de eroare, ceea ce ar fi facut debugging-ul dificil, iar codul nu era tocmai lizibil.

### Ce am schimbat si de ce ?
1. Am inlocuit `atoi` cu `strtol(..., NULL, 10)` pentru conversia corecta a timestamp-ului.
2. Am adaugat ramura `else` cu `fprintf(stderr, "Camp necunoscut: %s\n", field)` pentru o buna vizualizare a codului.

### Ce am invatat ?
AI-ul genereaza cod corect structural dar poate rata detalii de tip (int vs long).
Intotdeauna trebuie verificata compatibilitatea tipurilor, mai ales pentru `time_t`,
`off_t`, `ssize_t` care variaza cu arhitectura.

## Concluzie generala in urma colaborarii cu AI in scrierea codului: 
Functiile generate de AI au oferit un schelet bun si corect logic, dar au necesitat
corectii importante la nivel de:
- algoritm (strtok vs strchr) - la prima functie 
- tip de date (atoi vs strtol) - la a doua functie 
- robustete (verificari dimensiuni, mesaje de eroare) - la cea de a doua functie 

Folosirea AI-ului a accelerat scrierea efectiva a codului, dar revizuirea linie-cu-linie
a fost esentiala si a descoperit bug-uri reale care ar fi produs comportament incorect.
Colaborarea cu Inteligenta Artificiala a fost de ajutor, dar fiecare linie de cod trebuie verificata pentru a nu se pune problema unor erori!

## FAZA 2: Procese și Semnale

## FAZA 2: Procese și Semnale

### 1. Optimizarea și securizarea `monitor_reports.c` (Standardul POSIX)
* **Prompt dat AI-ului:** "Am scris acest cod pentru monitor_reports.c. Verifică-l ca și cum ai fi un prof exigent."
* **Ce a observat AI-ul:** Deși codul meu compila și funcționa la teste, AI-ul mi-a atras atenția asupra unei erori critice de standard POSIX. Folosisem funcțiile `printf`, `localtime` și `strftime` direct în interiorul handler-ului `handler_sigusr1`. Aceste funcții nu sunt "async-signal-safe" (pot bloca programul dacă întrerup un alt syscall).
* **Ce am schimbat:** Am refăcut arhitectura. Am declarat o variabilă `static volatile sig_atomic_t reports_pending = 0;` pe care doar o incrementez în handler. Formatarea timpului și afișarea cu `printf` le-am mutat în siguranță în bucla principală `while(running)` din `main()`.

### 2. Explicarea funcției de comunicare inter-proces (`notify_monitor`)
* **Interacțiunea cu AI-ul:** Am cerut explicații detaliate despre cum funcționează IPC (Inter-Process Communication) prin semnale în funcția scrisă.
* **Ce am învățat:** Am asimilat faptul că apelul de sistem `kill()` în C nu este destinat doar pentru a "omorî" un proces, ci este mecanismul principal pentru trimiterea de semnale (cum ar fi `SIGUSR1`). De asemenea, am înțeles importanța abordării "fail-fast": verificarea la fiecare pas dacă fișierul `.monitor_pid` s-a deschis, dacă s-a citit corect și dacă PID-ul este un număr valid (mai mare ca 0), înainte de a trimite semnalul.

### 3. Validarea securității pentru `op_remove_district`
* **Cum am colaborat:** Am rugat AI-ul să verifice logica funcției care creează un proces copil pentru a șterge folderul districtului.
* **Concluzii:** AI-ul a validat utilitatea liniei de securitate `if (strchr(district, '/') || strcmp(district,"..") == 0)`. Am învățat că apelarea unei comenzi externe precum `rm -rf` direct dintr-un program C prin `exec` expune sistemul la atacuri de tip Path Traversal, iar igienizarea inputului primit de la utilizator este obligatorie.

### 4. Sincronizarea proceselor și verificarea ieșirii (`waitpid`)
* **Interacțiunea:** Am discutat despre cum știe procesul părinte dacă comanda rulată de copil a avut succes.
* **Ce am învățat:** Am înțeles necesitatea utilizării macrourilor `WIFEXITED(status)` și `WEXITSTATUS(status)`. Așteptarea copilului cu `waitpid` nu este suficientă; trebuie verificat și codul real de ieșire al procesului clonat pentru a confirma dacă folderul a fost cu adevărat șters sau dacă sistemul de operare a întors o eroare (ex. lipsă permisiuni).

### 5. Alegerea corectă din familia de funcții `exec`
* **Ce am învățat:** AI-ul m-a ajutat să înțeleg de ce `execl` a fost alegerea potrivită în locul altor variante (`execv`, `execvp`). Deoarece cunoșteam dinainte numărul exact de argumente și ordinea lor (`"rm"`, `"-rf"`, `district`), `execl` (unde "l" vine de la listă) mi-a permis să scriu un cod mai curat, fără a fi nevoie să aloc manual un array de pointeri.



## CONCLUZIE FINALĂ

Utilizarea asistentului AI pe parcursul acestor două etape a reprezentat un sprijin educațional major. În loc să fie folosit ca un simplu generator de cod, AI-ul a funcționat ca un code-reviewer și un mentor pentru mine

În **Faza 1**, interacțiunea m-a ajutat să înțeleg manipularea corectă a string-urilor în C și a permisiunilor de fișiere (POSIX). În **Faza 2**, sprijinul a fost esențial pentru asimilarea unor concepte mult mai complexe: comunicarea între procese,, clonarea proceselor cu `fork()` și `exec()`, precum și gestionarea corectă și sigură a handler-elor de semnale (conceptul de *async-signal-safety*). 

Cea mai importantă deprindere formată a fost "defensive programming" – validarea strictă a datelor de intrare și verificarea obligatorie a fiecărui apel de sistem pentru a construi o aplicație de sistem robustă și sigură.
