
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>

#define PID_FILE ".monitor_pid"

// Folosim sig_atomic_t pentru a garanta ca citirea/scrierea nu e intrerupta la jumatate
static volatile sig_atomic_t running = 1;
static volatile sig_atomic_t reports_pending = 0;

/* 
   HANDLER-E DE SEMNALE

 - Handler pentru SIGUSR1 – un raport nou a fost adaugat
 - Regula POSIX stricta: Nu facem printf sau alocari in handler
 - Doar setam/incrementam un flag pe care il va citi main().
*/

static void handler_sigusr1(int sig) {
  (void)sig; // evitam warning unused parameter 
    reports_pending++; 
}


// Handler pentru SIGINT – oprire program (Ctrl+C)
 
static void handler_sigint(int sig) {
    (void)sig;
    running = 0;
}


//   FUNCTII HELPER

// Scrie PID-ul curent in fisierul .monitor_pid 
static int write_pid_file(void) {
    int fd = open(PID_FILE, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd == -1) {
        perror("Eroare la creare .monitor_pid");
        return -1;
    }

    char buf[32];
    snprintf(buf, sizeof(buf), "%d\n", (int)getpid());
    
    // Verificam strict daca scrierea a reusit
    ssize_t w = write(fd, buf, strlen(buf));
    if (w == -1) {
        perror("Eroare la scriere in .monitor_pid");
        close(fd);
        return -1;
    }
    
    close(fd);
    printf("MONITOR: PID %d scris in %s\n", (int)getpid(), PID_FILE);
    return 0;
}

// Sterge fisierul .monitor_pid la oprire
static void delete_pid_file(void) {
    if (unlink(PID_FILE) == -1) {
        perror("Eroare la stergere .monitor_pid");
    } else {
        printf("MONITOR: Fisier %s sters.\n", PID_FILE);
    }
}

//mainn

int main(void) {
    printf("MONITOR: Pornire monitor_reports (PID=%d)\n", (int)getpid());

    // 1. Scriem PID-ul in .monitor_pid 
    if (write_pid_file() != 0) {
        return 1;
    }

    // 2. Configuram handler-ul pentru SIGUSR1 cu sigaction() 
    struct sigaction sa_usr1;
    memset(&sa_usr1, 0, sizeof(sa_usr1));
    sa_usr1.sa_handler = handler_sigusr1;
    sigemptyset(&sa_usr1.sa_mask);
    sa_usr1.sa_flags = SA_RESTART; // restarteaza syscall-uri intrerupte 

    if (sigaction(SIGUSR1, &sa_usr1, NULL) == -1) {
        perror("sigaction SIGUSR1");
        delete_pid_file();
        return 1;
    }

    // 3. Configuram handler-ul pentru SIGINT cu sigaction() 
    struct sigaction sa_int;
    memset(&sa_int, 0, sizeof(sa_int));
    sa_int.sa_handler = handler_sigint;
    sigemptyset(&sa_int.sa_mask);
    sa_int.sa_flags = 0;

    if (sigaction(SIGINT, &sa_int, NULL) == -1) {
        perror("sigaction SIGINT");
        delete_pid_file();
        return 1;
    }

    printf("MONITOR: Astept semnale... (SIGUSR1 = raport nou, SIGINT = oprire)\n");
    fflush(stdout);

    // 4. Bucla principala – aici procesam logica in siguranta 
    while (running) {
        
        // Verificam daca avem rapoarte in asteptare (setate de handler-ul SIGUSR1)
        while (reports_pending > 0) {
            
            time_t now = time(NULL);
            struct tm *ti = localtime(&now);
            char ts[32];
            strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", ti);

            printf("[%s] MONITOR: Raport nou adaugat intr-un district!\n", ts);
            fflush(stdout);
            
            reports_pending--; // Scadem un raport din "coada"
        }
        
        // Daca nu mai e nimic de procesat si inca rulam, adormim procesul pana la urmatorul semnal
        if (running) {
            pause(); 
        }
    }

    // 5. Am primit SIGINT - oprim 
    printf("\nMONITOR: Am primit SIGINT. Oprire monitor_reports.\n");
    fflush(stdout);

    // 6. Stergem .monitor_pid 
    delete_pid_file();

    return 0;
}
