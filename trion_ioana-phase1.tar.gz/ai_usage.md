# ai_usage.md – Documentarea utilizarii AI in cadrul proiectului (pentru construirea functiilor)

## Instrument folosit
Claude (claude-sonnet-4-20250514) – conversatie interactiva in claude.ai

## Functia 1: `parse_condition`

### Prompt dat AI-ului - in limba engleza 
> "I have a C string of the form `field:op:value` where op can be `==`, `!=`, `<`, `<=`, `>`, `>=`.
> Write a function `int parse_condition(const char *input, char *field, char *op, char *value)`
> that splits it into the three parts and returns 0 on success, -1 on error."

### Ce a generat AI-ul ?
AI-ul a generat o varianta care folosea `strtok(input, ":")` pentru a imparti sirul in tokeni.

### Ce am schimbat si de ce ?
Varianta cu `strtok` era gresita, deoarece `strtok` ar fi spart sirul dupa **orice** `:`, inclusiv
in interiorul unui operator compus (`<=`, `>=`). De exemplu, pentru `severity:>=:2` ar fi
produs field=`severity`, op=`>`, value=`=:2`, ceea ce ar fi fost incorect.

Am rescris functia folosind `strchr` - care ne ajuta sa cautam un singur caracter, pentru a cauta manual primul si al doilea `:`, calculand lungimile substring-urilor cu pointer aritmetic. Aceasta abordare pastreaza corect operatorul de doua caractere, spre deosebire de strtok.

De asemenea AI-ul nu verifica dimensiunile bufferelor de iesire, iar acest lucru poate duce la buffer overflow.
Am adaugat verificarile `flen >= 32` si `olen >= 4`.

### Ce am invatat implementand aceasta functie cu ajutorul AI?
`strtok` nu e potrivit cand delimitatorul apare si in interiorul unui token valid.
Aritmetica de pointeri cu `strchr` ofera control precis

## Functia 2: `match_condition`

### Prompt dat AI-ului
> "Given this C struct:
> ```c
> typedef struct {
>     int    id;
>     char   inspector[64];
>     float  latitude;
>     float  longitude;
>     char   category[32];
>     int    severity;
>     time_t timestamp;
>     char   description[128];
> } Report;
> ```
> Write `int match_condition(Report *r, const char *field, const char *op, const char *value)`
> that returns 1 if the record satisfies `field op value`, 0 otherwise.
> Support fields: severity, category, inspector, timestamp.
> Operators: ==, !=, <, <=, >, >=."

### Ce a generat AI-ul ?

AI-ul a generat o functie cu structura corecta (if/else pe field, if/else pe operator),
dar cu doua probleme:

1. Pentru campul `timestamp` folosea `atoi(value)` care returneaza `int` – incorect,
   deoarece `time_t` pe sisteme moderne e `long` (64 biti). Valori mari de timestamp
   erau trunchiate si astfel apareau probleme.

2. Nu exista un `else` final pentru camp necunoscut – functia returna 0 in tacere,
   fara niciun mesaj de eroare, ceea ce ar fi facut debugging-ul dificil, iar codul nu era tocmai lizibil.

### Ce am schimbat si de ce ?
1. Am inlocuit `atoi` cu `strtol(..., NULL, 10)` pentru conversia corecta a timestamp-ului.
2. Am adaugat ramura `else` cu `fprintf(stderr, "Camp necunoscut: %s\n", field)` pentru o buna vizualizare a codului.

### Ce am invatat ?
AI-ul genereaza cod corect structural dar poate rata detalii de tip (int vs long).
Intotdeauna trebuie verificata compatibilitatea tipurilor, mai ales pentru `time_t`,
`off_t`, `ssize_t` care variaza cu arhitectura.

## Concluzie generala in urma colaborarii cu AI in scrierea codului: 
Functiile generate de AI au oferit un schelet bun si corect logic, dar au necesitat
corectii importante la nivel de:
- algoritm (strtok vs strchr) - la prima functie 
- tip de date (atoi vs strtol) - la a doua functie 
- robustete (verificari dimensiuni, mesaje de eroare) - la cea de a doua functie 

Folosirea AI-ului a accelerat scrierea efectiva a codului, dar revizuirea linie-cu-linie
a fost esentiala si a descoperit bug-uri reale care ar fi produs comportament incorect.
Colaborarea cu Inteligenta Artificiala a fost de ajutor, dar fiecare linie de cod trebuie verificata pentru a nu se pune problema unor erori!
